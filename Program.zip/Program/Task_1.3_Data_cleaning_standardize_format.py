import pandas as pd

try:
    file = 'c:/Users/rdeva/Downloads/Handled_missing_values.csv' 
    data = pd.read_csv(file)
    print("Dataset loaded successfully!")
    if 'Source_Station_Name' in data.columns and 'Destination_Station_Name' in data.columns:
        data['Source_Station_Name'] = data['Source_Station_Name'].str.upper()
        data['Destination_Station_Name'] = data['Destination_Station_Name'].str.upper()
        print("\nStation names standardized to uppercase")
    else:
        print("\nError: 'Source_Station_Name' or 'Destination_Station_Name' columns not found.")
    output = 'C:/Users/rdeva/Standardized_Station_Name.csv'
    data.to_csv(output, index=False)
    print(f"\nDataset with standardized station names saved to: {output}")

except Exception as e: 
    print("An error occurred:", e)