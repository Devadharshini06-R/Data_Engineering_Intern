import pandas as pd
import matplotlib.pyplot as plt
file = "c:/Users/rdeva/Downloads/Railway.info.csv"
data = pd.read_csv(file)
daywise_counts = data['days'].value_counts()
plt.figure(figsize=(10,6))
daywise_counts.plot(kind= "bar",color="blue",edgecolor="black")
plt.title('Number of train operating on each day of the week')
plt.xlabel('Day of the week')
plt.ylabel('Number of trains')
plt.xticks(rotation=45)
plt.grid(axis='y',linestyle="--",alpha=0.7)
plot_saved = "c:/Users/rdeva/Downloads/Correlation and Insights.png"
plt.savefig(plot_saved)
plt.show()
print(daywise_counts)