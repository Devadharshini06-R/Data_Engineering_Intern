import pandas as pd 
file = "c:/Users/rdeva/Downloads/Railway.info.csv"
railway_data = pd.read_csv(file)
saturday_trains = railway_data[railway_data["days"]=='Saturday']
output= "c:/Users/rdeva/Downloads/saturday_trains.csv"
saturday_trains.to_csv(output,index =False)
print(f"trains operating on saturday have been saved to {output}")