
import pandas as pd 
file = "c:/Users/rdeva/Downloads/Railway.info.csv"
data = pd.read_csv(file)
num_trains = data["Train_No"].nunique()
unique_source_stations = data["Source_Station_Name"].nunique()
unique_destination_stations = data["Destination_Station_Name"].nunique()
most_common_source= data["Source_Station_Name"].mode()[0]
most_common_destination = data["Destination_Station_Name"].mode()[0]
print(f"Number of Trains:{num_trains}")
print(f"Number of Source station:{unique_source_stations}")
print(f"Number of Destination station:{unique_destination_stations}")
print(f"Most common Source station:{most_common_source}")
print(f"Most common Destination station:{most_common_destination}")