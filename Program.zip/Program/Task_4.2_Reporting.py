import pandas as pd

file ="c:/Users/rdeva/Downloads/Railway.info.csv"
data = pd.read_csv(file)

data_info = data.info()
data_head = data.head()

import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter

sns.set(style="whitegrid")

days_count = Counter(data['days'])
days_df = pd.DataFrame(days_count.items(), columns=["day","frequency"]).sort_values(by="frequency",ascending = False)

plt.figure(figsize=(10,6))
sns.barplot(x="day",y="frequency",data= days_df, palette="Blues_d")
plt.title("Frequency of trains operating on different days")
plt.xlabel("days")
plt.ylabel("Number of trains")
plt.xticks(rotation=45)
plt.tight_layout()

plot_saved= "c:/Users/rdeva/Downloads/train days frequency.png"
plt.savefig(plot_saved)
plt.show()

top_sources = data["Source_Station_Name"].value_counts().head(10)
top_destinations = data["Destination_Station_Name"].value_counts().head(10)

top_sources, top_destinations

fig, ax = plt.subplots(1,2,figsize=(16,8))

sns.barplot(y=top_sources.index, x=top_sources.values,  palette="Purples_d", ax=ax[0])
ax[0].set_title("top 10 source station")
ax[0].set_xlabel("Number of Departures")
ax[0].set_ylabel("Source Station")
sns.barplot(y=top_destinations.index,x= top_destinations.values , palette="Greens_d",ax=ax[1])
ax[1].set_title("top 10 destination station")
ax[1].set_xlabel("Number of Arrivals")
ax[1].set_ylabel("destination Station")
plt.tight_layout()

plot_saved_stations = "c:/Users/rdeva/Downloads/top station distribution.png"
plt.savefig(plot_saved_stations)
plt.show()

plot_saved, plot_saved_stations