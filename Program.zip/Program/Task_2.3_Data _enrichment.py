import pandas as pd 
file = "c:/Users/rdeva/Downloads/Railway.info.csv"
data = pd.read_csv(file)
def categorize_days(day):
    weekend = {'Saturday','Sunday'}
    return 'weekend' if day in weekend else 'Weekday'
data["category"]= data["days"].apply(categorize_days)
output= "c:/Users/rdeva/Downloads/data enrichement.csv"
data.to_csv(output,index=False)
print(f"saved to {output}")
