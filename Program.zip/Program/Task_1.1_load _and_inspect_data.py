
import pandas as pd 
file="C:/Users/rdeva/Downloads/Railway.info.csv"
data = pd.read_csv(file)
print(data.head(10))
print(data.info())
print(data.isnull().sum())
output_1 ="C:/Users/rdeva/Downloads/first_10_rows.csv"
output_2 ="C:/Users/rdeva/Downloads/missing_value.csv"
data.head(10).to_csv(output_1,index=False)
missing_values = pd.DataFrame({'Column': data.columns, 'Missing Values': data.isnull().sum().values})
missing_values.to_csv(output_2, index=False)
print(f"First 10 rows saved to {output_1}")
print(f"Missing values summary saved to {output_2}")
