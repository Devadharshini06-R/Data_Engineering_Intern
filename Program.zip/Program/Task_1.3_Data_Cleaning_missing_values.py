import pandas as pd
try:
    file = "c:/Users/rdeva/Downloads/Railway.info.csv"
    data = pd.read_csv(file)
    print("data loaded successfully!!")
    print("\nInitial Dataset info:")
    print(data.info())
    print("\nmissing values before cleaning:\n",data.isnull().sum())
    data.fillna("N/A",inplace = True)
    print("\nmissing values after cleaning:\n",data.isnull().sum())
    output = "c:/Users/rdeva/Downloads/Handled_missing_values.csv"
    data.to_csv(output,index=False)
    print(f"\nDataset after handling missing values saved to :{output}")
except Exception as e:
    print("an error occured:",e)