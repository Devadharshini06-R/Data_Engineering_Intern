import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns 

try:
    file= "c:/Users/rdeva/Downloads/Railway.info.csv"
    data = pd.read_csv(file)
    if data.empty:
        print("The dataset is empty.please provide valid dataset")
    else:
        source_station_counts = data["Source_Station_Name"].value_counts().head(10)
        plt.figure(figsize=(12,6))
        sns.barplot(x=source_station_counts.index, y= source_station_counts.values, palette="viridis")
        plt.title("Number of trains starting from Top 10 source station")
        plt.xlabel("source station")
        plt.ylabel("Number of trains")
        plt.xticks(rotation=45)
        plot_saved_1 = "c:/Users/rdeva/Downloads/Number of trains starting from Top 10 source station.png"
        plt.savefig(plot_saved_1)
        plt.show()
        daywise_distribution =data["days"].value_counts()
        plt.figure(figsize=(10,5))
        sns.lineplot(x=daywise_distribution.index, y= daywise_distribution.values, palette="viridis")
        plt.title("Daywise distribution of trains ")
        plt.xlabel("Day of operation")
        plt.ylabel("Number of trains")
        plt.tight_layout()
        plot_saved_2= "c:/Users/rdeva/Downloads/Daywise distribution of trains.png"
        plt.savefig(plot_saved_2)
        plt.show()
        sample_data = data.sample(min(500,len(data)))
        station_pivot=sample_data.pivot_table(index="Source_Station_Name",columns="Destination_Station_Name",aggfunc="size",fill_value=0)
        plt.figure(figsize=(12,10))
        sns.heatmap(station_pivot,cmap ="coolwarm",cbar=True,linewidths=0.5)
        plt.title("Source vs Destination stations heatmap(sample)")
        plt.xlabel("Destination station")
        plt.ylabel("source station")
        plt.tight_layout()
        plot_saved_3 = "c:/Users/rdeva/Downloads/Source vs Destination stations heatmap(sample).png"
        plt.savefig(plot_saved_3)
        plt.show()
except FileNotFoundError:
    print("the file 'Railway.info.csv' was not found. please ensure the file is in the correct directory")
except pd.errors.EmptyDataError:
    print("the file is empty. please provide a vaild dataset")
except Exception as e:
    print(f"an error occured:{e}")

plot_saved_1,plot_saved_2,plot_saved_3



