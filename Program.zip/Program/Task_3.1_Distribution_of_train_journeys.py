import pandas as pd
import matplotlib.pyplot as plt
file = "c:/Users/rdeva/Downloads/Railway.info.csv"
data = pd.read_csv(file)
weekly_distribution = data['days'].value_counts()
plt.figure(figsize=(10,6))
weekly_distribution.plot(kind="bar",color="blue",edgecolor="black")
plt.title('Distribution of Train Journeys Throughout the week')
plt.xlabel("Day of the week")
plt.ylabel('Number of train journeys')
plt.xticks(rotation=45)
plt.grid(axis="y",linestyle="--",alpha=0.7)
plot_saved= "c:/Users/rdeva/Downloads/Distribution of train journey.png"
plt.savefig(plot_saved)
plt.tight_layout()
plt.show()

