import pandas as pd 
file = "c:/Users/rdeva/Downloads/Railway.info.csv"
railway_data = pd.read_csv(file)
train = railway_data.groupby("Source_Station_Name").size().reset_index(name="train count")    
print(train)
output= "c:/Users/rdeva/Downloads/grouping.csv"
train.to_csv(output,index =False)
print(f"trains operating on grouping have been saved to {output}")