import pandas as pd
file = "c:/Users/rdeva/Downloads/Railway.info.csv"
railway_data = pd.read_csv(file)
specific_station ='MADGOAN JN.' 
trains_from_station = railway_data[railway_data['Source_Station_Name']== specific_station]
output = f'trains_from_{specific_station.replace(" "," ")}.csv'
trains_from_station.to_csv(output,index =False)
print(f"trains starting from {specific_station} have been saved to {output}")
