import pandas as pd 
file = "c:/Users/rdeva/Downloads/Railway.info.csv"
railway_data = pd.read_csv(file)
unique_days = railway_data["days"].nunique()
average_trains_per_days=(railway_data.groupby("Source_Station_Name").size()/unique_days).reset_index(name="Average trains per days")
print(average_trains_per_days)
output= "c:/Users/rdeva/Downloads/aggregate.csv"                                                                                      
average_trains_per_days.to_csv(output,index =False)
print(f"average number trains per days have been saved to {output}")